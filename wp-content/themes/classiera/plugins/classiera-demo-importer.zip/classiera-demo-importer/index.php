<?php
/*
Plugin Name: Classiera Demo Importer
Plugin URI: http://joinwebs.com/
Description: Classiera Dummy data importer, This plugin is used to import dummy content for classiera theme, After to import dummy content please deactivate this plugin.
Version: 1.3
Author: JoinWebs
Author URI: http://joinwebs.com/
License: GPLv2
*/
?>
<?php 
include_once('loader.php');
?>